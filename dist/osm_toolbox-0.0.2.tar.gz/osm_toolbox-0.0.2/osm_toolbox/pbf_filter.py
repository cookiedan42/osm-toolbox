from .base import *
import os
from typing import Dict
from collections.abc import Iterable
# from shapely.strtree import STRtree
from shapely.ops import unary_union
from shapely.prepared import prep
import shapely.wkt as wkt

from enum import Enum

class DefaultValues(Enum):
    IDENTITY = lambda x:x
    NO_ARG= None

class OSMtype():
    '''remove magic methods from functions'''
    NODE = "node"
    WAY = "way"
    AREA = "area"
    RELATION = "relation"

#TODO: figure out how to settle relations properly :(


def filter_byProximity(sourcePath: str, features: Iterable, bufferDistance: float,
                       featureType: Iterable = {"node","way","area"},
                       transformFunc=DefaultValues.IDENTITY) -> dict:
    # take in a .pbf file and an iterable of shapely features
    # return the id of all pbf features within buffer distance of features
    # transformFunc maps osm feature shape into a different projection
    ref_multiPoly = prep(unary_union([i.buffer(bufferDistance) for i in features]))

    result = {
        k: set() for k in featureType if k in 
        {OSMtype.NODE, OSMtype.WAY, OSMtype.AREA}
    }

    def proximityTest(testWKT) -> bool:
        '''
        take wkt form of osm.pbf shape
        return True if it intersects ref_multiPoly
        '''
        testShape = transformFunc(wkt.loads(testWKT))
        return ref_multiPoly.intersects(testShape) 
            
    if OSMtype.NODE not in featureType:
        nodeCallback = None
    else:
        def nodeCallback(feature):
            fwkt = osm.geom.WKTFactory().create_point(feature)
            if proximityTest(fwkt):
                result[OSMtype.NODE].add(feature.id)

    if OSMtype.WAY not in featureType:
        wayCallback = None
    else:
        def wayCallback(feature):
            fwkt = osm.geom.WKTFactory().create_linestring(feature)
            if proximityTest(fwkt):
                result[OSMtype.WAY].add(feature.id)

    if OSMtype.AREA not in featureType:
        areaCallback = None
    else:
        def areaCallback(feature):
            fwkt = osm.geom.WKTFactory().create_multipolygon(feature)
            if proximityTest(fwkt):
                result[OSMtype.AREA].add(feature.id)

    osm.make_simple_handler(
        node=nodeCallback,
        way=wayCallback,
        area=areaCallback).apply_file(sourcePath)
    
    return result


def get_copy_ID(
    sourcePath:str,
    data: Dict =DefaultValues.NO_ARG,
    node: Iterable=set(),
    way: Iterable=set(),
    relation:Iterable=set(),
    area:Iterable=set()):
    '''
    taking iterables of osmID by type, return all the osmIDs that are required to represent this data
    params:
        filePath : path to source.pbf file
        data : dict of iterables {"node":[],"way":[],...}
                data takes higher precedence over other 
        node : iterable of node IDs
        way : iterable of way IDs
        relation : iterable of relation IDs
        area : iterable of area IDs
    returns :
        dictionary of all IDs that need to be copied
        {"node":set(),"way":set(),"relation":set()}
    '''
    # copy each of the input sets
    if data == DefaultValues.NO_ARG:
        node = set(node)
        way = set(way)
        relation = set(relation)
        area = set(area)
    else: #data is a dictionary
        node = data.get(OSMtype.NODE,set())
        way = data.get(OSMtype.WAY,set())
        relation = data.get(OSMtype.RELATION,set())
        area = data.get(OSMtype.AREA,set())

    toWrite = {
        OSMtype.NODE:node,
        OSMtype.WAY:way,
        OSMtype.RELATION:relation
        }

    # resolve areas
    if len(area) > 0:
        def areaFunc(feature):
            if feature.id in area:
                if feature.from_way():  # from way
                    way.add(feature.orig_id())
                else:   # from relation
                    relation.add(feature.orig_id())
        # extract areas and add into way and relation
        osm.make_simple_handler(area=areaFunc).apply_file(sourcePath)
    
    # recursively resolve all relations 
    if len(relation) > 0:
        def relationFunc(feature):
            if feature.id in unresolved:
                unresolved.remove(feature.id)
                for member in feature.members:
                    if member.type == 'r':
                        unresolved.add(member.ref)
                        relation.add(member.ref)
                    elif member.type == 'w':
                        way.add(member.ref)
                    elif member.type == 'n':
                        node.add(member.ref)

        unresolved = relation.copy()
        while len(unresolved) > 0:
            osm.make_simple_handler(relation=relationFunc).apply_file(sourcePath)

    if len(way) > 0:
        # deconstruct way into nodereflist --> add to node if way is to be copied
        def wayFunc(feature):
            if feature.id in way:
                for n in feature.nodes:
                    node.add(n.ref)
        osm.make_simple_handler(way=wayFunc).apply_file(sourcePath)
    return toWrite

def get_relation_members(sourcePath:str,relation:Iterable):
    '''
    take in an iterable of relations
    return the members of each relation as a dictionary
    key = relationID
    value = list of (id,featureType)
    '''

    relation = set(relation)
    result = {}

    def relationFunc(feature):
        if feature.id not in relation:
            return
        # else extract tags and members
        result[feature.id] = dict()
        result[feature.id]["tags"] = {tag.k:tag.v for tag in feature.tags}
        result[feature.id]["members"] = [(mem.type,mem.ref) for mem in feature.members]

    osm.make_simple_handler(relation=relationFunc).apply_file(sourcePath)

    return result

def writeFeatures(
    sourcePath:str,
    destPath:str,
    data: Dict = None,
    node: Iterable=set(),
    way: Iterable=set(),
    relation: Iterable=set()):
    '''
    take sets of osmID and write the data from sourcePath to destPath
    both as osm.pbf
    '''

    if data != None:
        node = data.get(OSMtype.NODE,set())
        way = data.get(OSMtype.WAY,set())
        relation = data.get(OSMtype.RELATION,set())
    else:
        node = set(node)
        way = set(way)
        relation = set(relation)


    def nodeFunc(feature):
        if feature.id in node:
            writer.add_node(feature)
    # function to test node --> else do nothing

    def wayFunc(feature):
        if feature.id in way:
            writer.add_way(feature)

    def relationFunc(feature):
        if feature.id in relation:
            writer.add_relation(feature)


    writeHandler = osm.make_simple_handler(
        node = nodeFunc if len(node)> 0 else None,
        way = wayFunc if len(way)> 0 else None,
        relation = relationFunc if len(relation)> 0 else None)

    with PBFwriter(destPath,overwrite=True) as writer:
        writeHandler.apply_file(sourcePath)

    # return void

def pbfFilter(sourcePath: str,
    nodePred=None,
    wayPred=None,
    relationPred=None,
    areaPred=None)-> Dict:
    '''
    taking in predicate functions, return dictionary of sets of osm ID for features that satisfy predicate
    predicate should take in a feature and return a boolean value
    '''
    result = {
        "node":set(),
        "way":set(),
        "relation":set(),
        "area":set(),}

    def featureFunc(feature,predicate,target):
        if predicate(feature):
            target.add(feature.id)
    
    def nodeCallback(feature): 
        return featureFunc(feature, nodePred, result[OSMtype.NODE])
    def wayCallback(feature): 
        return featureFunc(feature, wayPred, result[OSMtype.WAY])
    def relationCallback(feature): 
        return featureFunc(feature, relationPred, result[OSMtype.RELATION])
    def areaCallback(feature): 
        return featureFunc(feature, areaPred, result[OSMtype.AREA])

    # run callbacks if predicate is not None
    osm.make_simple_handler(
        node = None if nodePred == None else nodeCallback,
        way = None if wayPred == None else wayCallback,
        relation = None if relationPred == None else relationCallback,
        area = None if areaPred == None else areaCallback
    ).apply_file(sourcePath)
    
    return result

def filter_by_tag(
    sourcePath:str,
    tags:dict,
    filterType="any",
    caseSensitive=True):
    '''
    filter .pbf file at sourcePath
    return a dict of {node:set()...} for individual features that fulfill the filter
    '''
    result = {
        "node":set(),"way":set(),
        "relation":set(),"area":set(),
    }

    # ensure that tags are in string form
    if caseSensitive:
        tags = {k:str(v) for k,v in tags.items() }
    else:
        tags = {k:str(v).lower() for k,v in tags.items() }

    def lower(s:str):
        if s == None:
            return None
        else:
            return s.lower()

    def featureFunc(feature,target:set):
        # check if each k:v matches with tag.k,tag.v
        # for each k:v pair --> check if tags.get(k) matches v
        tag_results = [v == lower(feature.tags.get(k)) for k,v in tags.items()]
        if filterType == "any" and any(tag_results):
            target.add(feature.id)
        elif filterType == "all" and all (tag_results):
            target.add(feature.id)
        # else not adding

    nodeFunc = lambda feature: featureFunc(feature,result["node"]) 
    wayFunc = lambda feature: featureFunc(feature,result["way"])
    relationFunc = lambda feature: featureFunc(feature,result["relation"])
    areaFunc = lambda feature: featureFunc(feature,result["area"])

    osm.make_simple_handler(
        node = nodeFunc,
        way = wayFunc,
        relation = relationFunc,
        area = areaFunc
        ).apply_file(sourcePath)
    return result



