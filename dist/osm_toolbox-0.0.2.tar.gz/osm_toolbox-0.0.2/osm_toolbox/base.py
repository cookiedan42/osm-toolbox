import osmium as osm
import os
from datetime import datetime, timedelta
from pyproj import CRS,Transformer
from shapely.ops import transform

class DATETIME_FORMATS():
    ISO_8601_TZ = "%Y/%m/%d %H:%M:%S%z"
    # YYYY/MM/DD HH:MM:SS+TZTZ
    CONCAT_DATETIME = "%Y%m%d%H%M%S%z"
    # YYYYMMDDHHMMSSTZTZ used in ref data

def datetime_to_timestamp(dt: datetime) -> str:
    # convert timestamps from datetime object to YYYY/mm/dd HH:MM:ss+zone
    return dt.strftime(DATETIME_FORMATS.ISO_8601_TZ)
def timestamp_to_datetime(st: str) -> datetime:
    # convert timestamps from YYYY/mm/dd HH:MM:ss+zone to datetime object
    return datetime.strptime(st, DATETIME_FORMATS.ISO_8601_TZ)
def ref_to_datetime(st: str) -> datetime:
    # convert ref_data timestamps to UTC datetime object
    return datetime.strptime(f"{st}+0000", DATETIME_FORMATS.CONCAT_DATETIME) - timedelta(hours=8)
def ref_to_timestamp(st:str)-> str:
    # convert ref data to standard timestamp
    return datetime_to_timestamp(ref_to_datetime(st))


# use static definitions to avoid recomputation every call
svy21 = CRS("EPSG:3414")
wgs84 = CRS('EPSG:4326')

# transform x,y coords
wgs84_svy21 = Transformer.from_crs(wgs84, svy21, always_xy=True).transform

def wgs84_to_svy21(shape):
    # transform shapely object
    return transform(wgs84_svy21, shape)

# transform x,y corrdinate
svy21_wgs84 = Transformer.from_crs(svy21,wgs84, always_xy=True).transform

def svy21_to_wgs84(shape):
    # transform coordinate
    return transform(svy21_wgs84, shape)


class PBFwriter(osm.SimpleWriter):
    '''
    wrapper around osmium SimpleWriter
    adds context manager --> with writer as w
    add overwriting existing target file as default behaviour
    '''

    def __init__(self,destPath:str,overwrite:bool=True):
        if overwrite and os.path.exists(destPath):
            os.remove(destPath)
        super().__init__(destPath)

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()




# class datetime_converters():
#     @staticmethod
#     def datetime_to_timestamp(dt: datetime) -> str:
#         # convert timestamps from datetime object to YYYY/mm/dd HH:MM:ss+zone
#         return dt.strftime(DATETIME_FORMATS.ISO_8601_TZ)
#     @staticmethod
#     def timestamp_to_datetime(st: str) -> datetime:
#         # convert timestamps from YYYY/mm/dd HH:MM:ss+zone to datetime object
#         return datetime.strptime(st, DATETIME_FORMATS.ISO_8601_TZ)
#     @staticmethod
#     def ref_to_datetime(st: str) -> datetime:
#         # convert ref_data timestamps to UTC datetime object
#         return datetime.strptime(f"{st}+0000", DATETIME_FORMATS.CONCAT_DATETIME) - timedelta(hours=8)
#     @staticmethod
#     def ref_to_timestamp(st:str)-> str:
#         # convert ref data to standard timestamp
#         return datetime_to_timestamp(ref_to_datetime(st))
