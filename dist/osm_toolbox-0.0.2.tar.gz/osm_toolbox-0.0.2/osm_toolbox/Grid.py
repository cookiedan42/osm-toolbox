from .base import *
import shapely.geometry as sg
from shapely.ops import prep
from shapely.strtree import STRtree


def divide_by_grid(test_features,grid_Features,grid_buffer = 0):
    '''
    given an iterable test_features containing features in a geojson dict structure
    and an iterable grid_Features containing grid polygons in a geojson dict structure
    return a dictionary where values contain
        "grid": grid feature
        "features": list of overlapping features
        
    optional buffer to define a buffer around the grid features
    '''
    # test_features is an iterable of featureShape objects
    grid_tree = STRtree(grid_Features)
    result = {id(grid):{"grid":grid,"features":[]} for grid in grid_Features}
    
    for test in test_features:
        testShape = test.shape
        if grid_buffer > 0:
            testShape = testShape.buffer(grid_buffer)
        parent_grids = grid_tree.query(testShape)
        for p in parent_grids:
            result[id(p)]["features"].append(test)
    return result



# throw grids into a tree
# test points intersect against them!