import json
import shapely.geometry as sg
from shapely.strtree import STRtree
from typing import List,Dict, Union, TypeVar
from collections.abc import Iterator,Iterable
# basically string keys are for raw geojson data
# attributes are for additional augmented data
# methods are for convinience
# advantage is that dictionary will be written w/o considering temp augmented data

def deepCopy(ds):
    '''
    makes a copy of listlike and dictlike ds ignoring additional attributes
    '''
    if isinstance(ds, list):
        return [deepCopy(i) for i in ds]
    elif isinstance(ds, dict):
        return {k: deepCopy(v) for k, v in ds.items()}
    # otherwise directly pass
    return ds


FeatureShape = TypeVar("FeatureShape")
FeatureCollection = TypeVar("FeatureCollection")


class FeatureShape(dict):
    '''
    Augmented Dictionary representation of geoJSON feature
    FeatureShape.shape - shapely object for geoJSON feature
    FeatureShape.shapeID - UUID based on shape
    '''
    __slots__ = ["shape", "shapeID"]

    def __init__(self, geoJSON_Dict):
        '''
        param geoJSON_Dict - Dictionary representation of a geoJSON feature
        '''
        self.update(deepCopy(geoJSON_Dict))
        self.shape = sg.shape(self["geometry"])
        self.shapeID = id(self.shape)

    def copy(self) -> FeatureShape:
        '''create a copy of the FeatureShape'''
        # export the underlying dictionary, then rebuild the new FeatureShape
        # keep the old shape and ID
        newFS = FeatureShape(self)
        newFS.shape = self.shape
        newFS.shapeID = self.shapeID
        return newFS

    def transform(self,transformer,transform_coords=False):
        '''
        transform projection of coordinates using a transformer
        Optional boolean transform_coords to also modify underlying data
        '''
        res = self.copy()
        res.shape = transformer(res.shape)
        res.shapeID = id(res.shape)
        if transform_coords:
            res["geometry"] = sg.mapping(res.shape)
        return res

    def __str__(self) -> str:
        # detailed repr of underlying geojson data
        return f"<{self.shape.type} Feature>" + json.dumps(self, indent=2)

    def __repr__(self) -> str:
        # simple repr using memory address
        return f"<{self.shape.type}Shape@{id(self)}>"

    def properties(self) -> dict:
        '''
        return properties dict if present, 
        return empty dictionary otherwise
        '''
        return self.get("properties", {})

    def geometry(self) -> dict:
        '''
        return geometry dict if present
        return empty dictionary otherwise
        '''
        return self.get("geometry",{})

class FeatureCollection(dict):
    '''
    augmented dictionary class for working with geoJSON FeatureCollection
    features key is a dictionary of geoJSON features and shapely objects keyed on id(shape)

    structured as a dictionary with extra attributes and methods
    '''
    __slots__ = []

    @classmethod
    def from_features(cls,features:Iterable)->FeatureCollection:
        '''
        create a featureCollection from iterable of features
        '''
        #create empty Feature Collection
        r = FeatureCollection({})
        r["features"] = {i.shapeID:i for i in features}
        return r

    def __init__(self, geoJSON_Dict):
        '''take in a geoJSON dictionary object as an argument
        '''
        # update self with empty geojson structure
        self.update({
            "type": "FeatureCollection",
            "features": []
        })
        self.update(deepCopy(geoJSON_Dict))
        self["features"] = [FeatureShape(i) for i in self["features"]]
        self["features"] = {i.shapeID: i for i in self["features"]}

    def transform(self, transformer,transform_coords=False)->FeatureCollection:
        '''transform shapely objects using transformer function
        returns a new FeatureCollection of transformed data

        transformer function takes in a shapely geometry and returns a new shapely geometry
        optional transform_coords to transform underlying geojson
        '''
        res = self.copy()
        for k,v in res["features"].items():
            res["features"][k] =  v.transform(transformer,transform_coords=transform_coords)
        res["features"] = {v.shapeID:v for v in res.features()}
        # for v in res.features():
        #     v.shape = transformer(v.shape)
        #     v.shapeID = id(v.shape)
        #     v["geometry"] = sg.mapping(v.shape)
        # res["features"] = {v.shapeID:v for v in res.features()}
        return res

    def features(self) -> Iterator:
        '''return an Iterator of the features in the feature colection'''
        return iter(self["features"].values())
    
    def shapes(self)-> Iterator:
        '''return a Iterator of the shapes in the feature collection'''
        return iter(i.shape for i in self["features"].values())

    def copy(self) -> FeatureCollection:
        '''return a copy of the object'''
        return FeatureCollection(self.to_geojson())

    def __len__(self) -> int:
        '''return number of features in the geojson'''
        return len(self["features"])

    def get(self, key, default=None):
        '''getter without KeyError, returns default value if not found'''
        try:
            return self[key]
        except KeyError:
            return default

    def __getitem__(self, key: Union[str, int]):
        '''
        return top level entry if keytype is a string
        return FeatureShape associated with memory address if key is integer
        '''
        if type(key) == str:
            return super().__getitem__(key)
        elif type(key) == int:
            return self["features"][key]

    def __setitem__(self, key, value):
        '''
        set top level entry if keytype is a string
        set FeatureShape if key is an integer
        '''
        if type(key) == str:
            super().__setitem__(key, value)
        elif type(key) == int:
            super()["features"][key] = value

    def to_geojson(self) -> Dict:
        '''
        return the geoJSON dictionary object representation of this object for writing
        ["features"] is restored to an array of features
        '''
        result = deepCopy(self)
        result["features"] = list(self["features"].values())
        return result

    def __repr__(self) -> str:
        # repr of all top level feature collection, then features
        r = "<FeatureCollection>{ "
        for k, v in self.items():
            if k == "features":
                continue
            r += f" {k}: {v},"
        return (r + f"features : {self['features']}" + "}")


def load(filePath) -> FeatureCollection:
    '''
    load a geoJSON file as a FeatureCollection
    '''
    with open(filePath, "r") as fp:
        return FeatureCollection(json.load(fp))


def dump(data: FeatureCollection, filePath):
    '''
    write  a FeatureCollection object to file
    '''
    with open(filePath, "w") as fp:
        json.dump(data.to_geojson(), fp)
