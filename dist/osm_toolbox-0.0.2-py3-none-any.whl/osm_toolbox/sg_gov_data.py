import json
from .base import *
from typing import Dict 

# cleanup govt data
def parseDesc(desc: str)-> Dict:
    # govt data is stored as a markup table
    # convert table into dict of {<th>:<td>}
    desc = desc.split('<th>')
    desc = [i for i in desc if "<td>" in i]
    desc = [i.split("</td>")[0] for i in desc]
    # elements in desc are now in form of "header</th><td>data"
    return {i.split("</th>")[0]:i.split("<td>")[1] for i in desc}

def clean_ref_GeoJSON(inPath:str,outPath: str=None)->Dict:
    # read source file
    with open(inPath,"r") as jsFile:
        source = json.load(jsFile)
        
    for feature in source["features"]:
        # convert Description to discrete properties
        for k,v in parseDesc(feature["properties"]["Description"]).items():
            if k == "FMEL_UPD_D":
                feature['properties']["timestamp"] = ref_to_timestamp(v)
                continue

            feature['properties'][k] = v
        del feature['properties']["Description"]
    # write out modified data
    if outPath !=None:
        with open(outPath,"w") as jsFile:
            json.dump(source,jsFile)
    return source