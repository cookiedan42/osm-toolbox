from .base import *
import json
from typing import Dict

def count_pbf_features(
    source:str  # path to .pbf file to count features of
)-> Dict:
    l = count_features()
    l.apply_file(source)
    return {
        "nodes":l.cNode,
        "ways":l.cWay,
        "relations":l.cRelation,
        "areas":l.cArea,
    }
class count_features(osm.SimpleHandler):
    def __init__(self):
        super().__init__()
        self.cNode = 0
        self.cWay = 0
        self.cRelation = 0
        self.cArea = 0
    def area(self,area):
        self.cArea +=1
    def node(self,k):
        self.cNode +=1
    def relation(self,k):
        self.cRelation+=1
    def way(self,k):
        self.cWay +=1



# convert osm_pcn data into .geojson format
def pcn_pbf_to_geoJSON(source:str,dest:str):
    PCN = PCN_geoJSON()
    PCN.apply_file(source,locations=True)
    with open(dest,"w") as jsFile:
        json.dump(PCN.geojson,jsFile)

class PCN_geoJSON(osm.SimpleHandler):
    def __init__(self):
        super().__init__()
        self.geojson = {
            "type": "FeatureCollection",
            "features": []
        }
    
    def way(self,way):
        entry = {
           "type": "Feature",
           "geometry":dict(),
           "properties": dict()
       }
        entry["geometry"] = json.loads(osm.geom.GeoJSONFactory().create_linestring(way))
        entry["properties"] = {tag.k:tag.v for tag in way.tags}
        entry["properties"]['osm_id'] = way.id
        entry['id'] = way.id
        entry["timestamp"] = datetime_to_timestamp(way.timestamp)
        self.geojson["features"] += [entry]
